package com.ramon.infogo

object UsuarioSingleton {
    var usuario: Usuario? = null
}
