package com.ramon.infogo

data class Incidencia(
    val nombre: String = "",
    val tipo: String = "",
    val descripcion: String = "",
    val username: String
)

