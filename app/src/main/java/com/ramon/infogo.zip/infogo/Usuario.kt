package com.ramon.infogo

data class Usuario(
    val email: String = "",
    var username: String = "",
    val profilePic: String = "",
    val password: String
)
